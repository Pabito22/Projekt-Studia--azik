#include <iostream>

void menu(){
    
}