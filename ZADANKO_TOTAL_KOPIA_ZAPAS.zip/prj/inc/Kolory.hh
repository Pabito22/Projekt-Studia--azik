#ifndef KOLORY_HH
#define KOLORY_HH

enum Kolory {
	     Kolor_JasnoNiebieski = 3,
	     Kolor_Czerwony = 15
};

#endif
