#pragma once 

#include "Lazik.hh"
#include "ProbkaRegolitu.hh"


/**
 * @brief Simulates the SFR Rover, which will be able to collect the Probes
 * 
 */
class LazikSFR: public Lazik
{

    private:

    /**
     * @brief List of the Probes collected by the SFR Rover
     * 
     */
    std::list<std::shared_ptr<ProbkaRegolitu>> _ListaProbek;


    public:

    /**
     * @brief Destroy the Lazik S F R object
     * 
     */
    virtual ~LazikSFR(){};

    /**
     * @brief Construct a new Lazik S F R object
     * Uses default constr values from lazik
     */
    LazikSFR()
    :Lazik()
    {
       
    };

    /**
     * @brief Get the ListaProbek object
     * 
     * @return std::list<std::shared_ptr<ProbkaRegolitu>> 
     */
    std::list<std::shared_ptr<ProbkaRegolitu>> get__ListaProbek()const{return _ListaProbek;}

    /**
     * @brief Get the acces to the ListaProbek object
     * 
     * @return std::list<std::shared_ptr<ProbkaRegolitu>>& 
     */
    std::list<std::shared_ptr<ProbkaRegolitu>> & get__ListaProbek(){return _ListaProbek;}

    /**
     * @brief Returns Id of LazikSFR class
     * 
     * @return int ID
     */
    virtual int SprawdzIDklasy()const override{return ID_KLASY_LAZIK_FSR;}

    //so do a function to print out all the probes on the rover
    //then check if function from Scena.cpp to take awa the probes work corretly
    //take care of drawing when the box is not anymore on the Scene
    
    /**
     * @brief Prints out colected Probes 
     * 
     */
    void Wypisz_Zebrane_Probki()const{
        for(std::_List_const_iterator<std::shared_ptr<ProbkaRegolitu>> iter = _ListaProbek.begin(); iter != _ListaProbek.end(); ++iter){
            if((*iter)->SprawdzIDklasy() == ID_KLASY_PROBAREGOLITU){std::cout<<(*iter)->get__NazwaObiektu()<<"\n";}
        }
    }

    virtual void  WyswietlLazik()const{
        std::cout<<"        Nazwa: "<<this->WezNazweObiektu()<<std::endl;
        std::cout<<"    Polozenie (x,y,z): "<<this->get_Polozenie()<<std::endl;
        std::cout<<     "Orientacja [st]: "<<this->get_KatOrientacji()<<std::endl;
        std::cout<<"lista Probek na Laziku SFR:\n";
        Wypisz_Zebrane_Probki();
    }


    /**
     * @brief If FSR 
     * 
     * @return TypKolizji 
     */
    virtual TypKolizji CzyKolizja(const std::shared_ptr<Lazik> &Wsk_Lazik)const override
    {
         if(this->get_Obrys().CzyNalozenie(Wsk_Lazik->get_Obrys())){
            return TK_Kolizja;
        }else{
            return TK_BrakKolizji;
        }
    }

};