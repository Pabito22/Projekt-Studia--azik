#ifndef WEKTOR3D_HH
#define WEKTOR3D_HH

#include "SWektor.hh"


typedef SWektor<double, ROZMIAR> Wektor3D;


#endif