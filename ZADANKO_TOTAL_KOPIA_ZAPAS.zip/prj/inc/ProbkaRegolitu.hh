#pragma once 

#include "ObiektGeom.hh"
///////////////////////////////////////////////////////////NEW
#include "Lazik.hh"
///////////////////////////////////////////////////////////NEW

class Lazik;


class ProbkaRegolitu: public ObiektGeom
{

    public:

    /**
     * @brief Construct a new Probka Regolitu object
     * 
     * @param sNazwaObiektu Name of the probe
     * @param KolorID 
     * @param x axis, where the probe will be
     * @param y axis, where the probe will be
     * @param z axis, where the probe will be
     */
    ProbkaRegolitu(const char* sNazwaObiektu, unsigned int KolorID, double x = 0, double y=0, double z = 0)
    :ObiektGeom("bryly_wzorcowe/szescian3.dat", sNazwaObiektu, KolorID)
    {
        //get__NazwaObiektu() += sNazwaObiektu;
        get_KolorID() = KolorID;
        get_Polozenie()[0] = x;
        get_Polozenie()[1] = y;
        get_Polozenie()[2] = z;
    }

    /**
     * @brief Destroy the Probka Regolitu object
     * 
     */
    virtual ~ProbkaRegolitu(){};

    /**
     * @brief Returns ID of the class
     * 
     * @return int 
     */
    virtual int SprawdzIDklasy()const override{return ID_KLASY_PROBAREGOLITU;}


    /**
     * @brief Calculates new Coordinates of a given obj in position relative to the givn Probe
     * 
     * @param Wsk_Na_Ob Poiter to a Lazik obj
     * @return Wektor3D 
     */
    Wektor3D Transformuj_Wsp_do_Probki(const std::shared_ptr<ObiektGeom> &Wsk_Na_Ob)const{
        if(!(Wsk_Na_Ob->SprawdzIDklasy()==ID_KLASY_LAZIK || Wsk_Na_Ob->SprawdzIDklasy()==ID_KLASY_LAZIK_FSR)){throw std::invalid_argument("Only Lazik allowed in this Function(Transformuj_Wsp_do_Probki!\n");}
        Wektor3D Wynik;
        Wynik[0] = Wsk_Na_Ob->get_Polozenie()[0] - this->get_Polozenie()[0];
        Wynik[1] = Wsk_Na_Ob->get_Polozenie()[1] - this->get_Polozenie()[1];
        Wynik[2] = 0;
        return Wynik;
    }


    /*this one will be virtual*/

    /**
     * @brief Checs if there is a collision between Probe and the Rover
     * 
     * @param P_Rover Rover with which the probe could possibly colide
     * @return TypKolizji 
     */
    virtual TypKolizji CzyKolizja(const std::shared_ptr<Lazik> &Wsk_Lazik)const override
    {  

        //calculate new coordinates and length between Rover and Probe
        Wektor3D Wsp_wzgledem_Probki = this->Transformuj_Wsp_do_Probki(Wsk_Lazik);
        std::cout<<"Nowe wsp: "<<Wsp_wzgledem_Probki<<"\n";
        double R_odleglosc = Wsp_wzgledem_Probki.get_Length();
        std::cout<<"odl wzg probki  : "<<R_odleglosc<<"\n";

        //get info obout speed Vec(in witch direction is rover moving)
        Wektor3D Speed_Vector; Speed_Vector[0] = cos(Wsk_Lazik->get_KatOrientacji()*PI/180);  Speed_Vector[1] = sin(Wsk_Lazik->get_KatOrientacji()*PI/180); Speed_Vector[2] = 0;
        double Lgth_ofSpeedVec = Speed_Vector.get_Length();


        std::cout<<"orientation angle: "<<Wsk_Lazik->get_KatOrientacji()<<'\n';

        std::cout<<"V vector: "<<Speed_Vector<<'\n';

        double D_distance =  (Wsp_wzgledem_Probki & Speed_Vector).get_Length()/Lgth_ofSpeedVec;     //now you have the distance
        std::cout<<"calculated d distance: "<<D_distance<<'\n';

        //here checking if probe and the rover are even connected
        //MAIGHT BE A PROBLEM THAT YOU WILL PROBABLY HAVE TO DO IT ALSO IN THE SECOND OPOSSIBLE WAY
        if(this->get_Obrys().CzyNalozenie(Wsk_Lazik->get_Obrys()) || Wsk_Lazik->get_Obrys().CzyNalozenie(this->get_Obrys())){
            if(D_distance < SZEROKOSC_LAZIKA/5){return TK_PrzejazdNadProbka;}   else{return TK_Kolizja;}
        }
        
        return TK_BrakKolizji;
    }

};