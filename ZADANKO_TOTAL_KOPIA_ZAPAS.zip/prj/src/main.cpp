#include <iostream>
#include <fstream>
#include "lacze_do_gnuplota.hh"
#include "PowierzchniaMarsa.hh"
#include "Lazik.hh"
#include "Kolory.hh"
#include "Scena.hh"
#include "unistd.h" //for uslepp
#include <memory>
#include "ObrysXY.hh"

//#include "ProbkaRegolitu.hh"

using namespace std;




int main()  
{
  
  
  //ProbkaRegolitu ProbkaUno("kokaina", Kolor_JasnoNiebieski);


  {//used to make all the wektors local


  //nowe
  //Skala (chyba definiuje wielkosc kloca)
  Wektor3D Skal1(20,20,10);
  Wektor3D Skal2(20,20,10);
  Wektor3D Skal3(20,20,10);

  //defines where the box will be
  Wektor3D Pol1(0,15,0);
  Wektor3D Pol2(60,60,0);
  Wektor3D Pol3(-20,70,0);
  

  //creating inteligent pointers to dynamicly allocated Rovers
  shared_ptr<LazikSFR> WskLazik_FSR(new LazikSFR());
  shared_ptr<Lazik> WskLazik_2(new Lazik("bryly_wzorcowe/szescian3.dat","Perseverance",Kolor_Czerwony, Skal2, Pol2,60));
  shared_ptr<Lazik> WskLazik_3(new Lazik("bryly_wzorcowe/szescian3.dat","Curiosity",Kolor_Czerwony, Skal3, Pol3));

  //creating ineligent pointers to dynamicly allocated Probes
  shared_ptr<ProbkaRegolitu> WskProbe1(new ProbkaRegolitu("Montdenier", Kolor_Czerwony,30,30,0));
  shared_ptr<ProbkaRegolitu> WskProbe2(new ProbkaRegolitu("Montagnac", Kolor_Czerwony,-30,-30,0));
  shared_ptr<ProbkaRegolitu> WskProbe3(new ProbkaRegolitu("Salette", Kolor_Czerwony,80,80));
  shared_ptr<ProbkaRegolitu> WskProbe5(new ProbkaRegolitu("Robine ", Kolor_Czerwony,80,-80));
  shared_ptr<ProbkaRegolitu> WskProbe4(new ProbkaRegolitu("Coulettes", Kolor_Czerwony,-80,-80));
  

  //create Mars surface
  Scena Mars_Scene(WskLazik_FSR,WskLazik_2,WskLazik_3, WskProbe1, WskProbe2, WskProbe3, WskProbe4, WskProbe5);

  
  cout << endl << "Start programu gnuplot" << endl << endl;
  Mars_Scene.get_Lacze().Rysuj();  //before Lacze.Rysuj();
  //Mars_Scene.ObrocOKat_anim(45);
  //Mars_Scene.PrzejedzDystans(20);
  Mars_Scene.WybierzLazika(2);
  Mars_Scene.PrzejedzDystans_anim(1);
  Mars_Scene.WybierzLazika(3);
  Mars_Scene.PrzejedzDystans_anim(1);
  Mars_Scene.WybierzLazika(1);
  Mars_Scene.get_AktywnyLazik().WyswietlLazik();


 
  Mars_Scene.Wyswietl_Probki_NaScenie();


  /*test of collision between Probe ant Rover*/
  /*
  shared_ptr<ProbkaRegolitu> PRONA(new ProbkaRegolitu("KOKO", Kolor_Czerwony,0,80,0));
  cout<<"\n\nPRONA KURWA----------------\n\n";
  cout<<"LD: "<<WskProbe1->get_Obrys().get_Wiersz_DolnyLewy()[0]<<"||||||"<<WskProbe1->get_Obrys().get_Wiersz_DolnyLewy()[1]<<endl;

  cout<<"PG : "<<WskProbe1->get_Obrys().get_Wiersz_GornyPrawy()[0]<<"||||||"<<WskProbe1->get_Obrys().get_Wiersz_GornyPrawy()[1]<<endl;

  cout<<"\n\nLAZIK PIERDOLONY KURWA----------------\n\n";

  cout<<"LD: "<<WskLazik_FSR->get_Obrys().get_Wiersz_DolnyLewy()[0]<<"||||||"<<WskLazik_FSR->get_Obrys().get_Wiersz_DolnyLewy()[1]<<endl;

  cout<<"PG : "<<WskLazik_FSR->get_Obrys().get_Wiersz_GornyPrawy()[0]<<"||||||"<<WskLazik_FSR->get_Obrys().get_Wiersz_GornyPrawy()[1]<<endl;


  if(WskProbe1->CzyKolizja(WskLazik_FSR)==TK_Kolizja){cout<<"KOOOOORWA!\n";}else{
    cout<<"CHOJNIA!\n";
  }*/

/*test of List managment
  cout<<"test usuwania probeczki ze sceneczki\n";
  cout<<"im printing out the probe on the SFR\n";
  WskLazik_FSR->Wypisz_Zebrane_Probki();
  cout<<"And now im going to dfelete smth bitch!\n";
  Mars_Scene.WezProbkeZeScenyDoLazika(WskProbe1);
  WskLazik_FSR->Wypisz_Zebrane_Probki();
  cout<<"And the Scene again!\n";
  Mars_Scene.Wyswietl_Probki_NaScenie();


  WskLazik_2->WyswietlLazik();

  shared_ptr<Lazik> WP = WskLazik_FSR;
  WP->WyswietlLazik();

  test        IT WORKS bITCH!*/
  
  

  cout << "Nacisnij klawisz ENTER, aby FSR wykonal przesuniecie." << endl;
  cin.ignore(100,'\n');

  


  //TO JE MENIU TEGO NIE USUWAJ KURWAAAA
  Mars_Scene.get_AktywnyLazik().WyswietlLazik();

  char WczytanyZnak;

  while(WczytanyZnak != 'k'){

    cout<<"Aktywny Lazik\n\n";
    Mars_Scene.get_AktywnyLazik().WyswietlLazik();

    cout<<"j - jazda na wprost\n";
    cout<<"o - zmien orientacje\n";
    cout<<"w - wybor lazika\n";
    cout<<"l - lista probek na scenie\n";
    cout<<"p - podejmij probke (tylko FSR)\n";
    cout<<"m - wyswietl menu\n\nk - koniec dzialania programu\n";
    

    cin>>WczytanyZnak;
    if(cin.fail()){throw std::invalid_argument("Nie podano znaku\n");}
    

    switch(WczytanyZnak){

      case 'j':
        {
        double dystans=0;

        cout<<"Twoj wybor, "<<WczytanyZnak<<" - jazda na wprost\n";
        cout<<"Podaj odleglosc, na ktora ma sie przemiescic lazik (w jednostkach sceny)\n";
        
        cin>>dystans;
        if(cin.fail()){throw std::invalid_argument("Nie podano liczby\n");}

        Mars_Scene.PrzejedzDystans_anim(dystans);  //animates and moves the rover
        
        }
    
      break;


      case 'o':
        {
        double obrot_calkowiy=0;

        cout<<"Twoj wybor, "<<WczytanyZnak<<" - zmien orientacje\n";
        cin>>obrot_calkowiy;
        if(cin.fail()){throw std::invalid_argument("Nie podano liczby\n");}

        Mars_Scene.ObrocOKat_anim(obrot_calkowiy);
        
        }
      break;

      case 'w':
        {
          uint Lazik_ID=0;
          cout<<"Twoj wybor, "<<WczytanyZnak<<" - wybor lazika\n";

          cout<<"Lazik numer: 1\n";
          Mars_Scene.WybierzLazika(1);
          Mars_Scene.get_AktywnyLazik().WyswietlLazik();

          cout<<"Lazik numer: 2\n";
          Mars_Scene.WybierzLazika(2);
          Mars_Scene.get_AktywnyLazik().WyswietlLazik();

          cout<<"Lazik numer: 3\n";
          Mars_Scene.WybierzLazika(3);
          Mars_Scene.get_AktywnyLazik().WyswietlLazik();

          cin>>Lazik_ID;
          if(cin.fail()){throw std::invalid_argument("Nie podano liczby\n");}

          if(Lazik_ID<=0||Lazik_ID> Mars_Scene.get_ObiektySceny().size()){
            throw std::invalid_argument("Nie ma takiego Lazika !\n");
          }

          //final user setting if everything right
          Mars_Scene.WybierzLazika(Lazik_ID);
        }
        break;

        case 'l':
            cout<<"Twoj wybor, "<<WczytanyZnak<<" - lista Probek\n";
            Mars_Scene.Wyswietl_Probki_NaScenie();
        break;

        case 'p':
          cout<<"Twoj wybor, "<<WczytanyZnak<<" - podjecie probki\n";
          Mars_Scene.Podejmij_probke();
          break;
        case 'm':
          cout<<"Twoj wybor, "<<WczytanyZnak<<" - menu\n";
        break;

      default:
        cout<<"cos nie halo podales \n";
      break;

      
    }

    
  }
  
  }//used to make all the Wektors local

  Wektor3D::Wyswietl_Ilosc_Wektorow();
}
